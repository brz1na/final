
(function(compId){var _=null,y=true,n=false,x1='6.0.0',x3='6.0.0.400',x2='5.0.0',e19='${RectangleCopy2}',x7='486px',x9='0px 0px',x15='rgba(192,192,192,0.00)',x10='35px 35px',w='width',x14='rect(0px 408.28515625px 493px 4px)',cl='clip',x21='rect(@@0@@px @@1@@px @@2@@px @@3@@px)',x16='true',x20='@@0@@px @@1@@px',x8='auto',rbr='border-bottom-right-radius',x18='490px',x4='rgba(255,255,255,0.00)',rtr='border-top-right-radius',x17='253px',x13='solid',m='rect',x6='397px',x12='rgba(198,152,107,1.00)',x5='0px',x11='RectangleCopy2',i='none';var im='images/',aud='media/',vid='media/',js='js/',fonts={},opts={'gAudioPreloadPreference':'auto','gVideoPreloadPreference':'auto'},resources=[],scripts=[],symbols={"stage":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{id:'simbolcina',symbolName:'simbolcina',t:m,r:['406px','5px','253','490','auto','auto']},{id:'simbolcina2',symbolName:'simbolcina',t:m,r:['163px','5px','undefined','undefined','auto','auto'],tf:[[],[],[],['-1.01075']]}],style:{'${Stage}':{isStage:true,r:['null','null','820px','500px','auto','auto'],overflow:'hidden',f:[x4]}}},tt:{d:5812,a:y,data:[]}},"simbolcina":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x5,x5,x6,x7,x8,x8],br:[x9,x10,x10,x9],t:m,id:x11,s:[2,x12,x13],cl:x14,f:[x15]}],style:{'${symbolSelector}':{isStage:x16,r:[undefined,undefined,x17,x18]}}},tt:{d:5812,a:y,data:[["eid26",rbr,4541,1271,"easeInOutSine",e19,[240,240],[35,35],{vt:x20}],["eid25",cl,4644,704,"easeInOutSine",e19,[0,408.28515625,493,4],[0,408.28515625,493,40],{vt:x21}],["eid27",rtr,4541,1271,"easeInOutSine",e19,[240,240],[35,35],{vt:x20}],["eid28",w,4000,1812,"easeInOutQuart",e19,'249px','397px']]}}};AdobeEdge.registerCompositionDefn(compId,symbols,fonts,scripts,resources,opts);})("radigovnobre");
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;Edge.registerEventBinding(compId,function($){
//Edge symbol: 'stage'
(function(symbolName){})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'simbolcina'
(function(symbolName){})("simbolcina");
//Edge symbol end:'simbolcina'
})})(AdobeEdge.$,AdobeEdge,"radigovnobre");