
(function(compId){var _=null,y=true,n=false,x1='6.0.0',x3='6.0.0.400',x2='5.0.0',x4='rgba(0,0,0,0)',lf='left',x6='rgba(255,255,255,1)',g='image',e7='${Pasted2}',i='none';var g5='Pasted2.svg';var im='images/',aud='media/',vid='media/',js='js/',fonts={},opts={'gAudioPreloadPreference':'auto','gVideoPreloadPreference':'auto'},resources=[],scripts=[],symbols={"stage":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{id:'Pasted2',t:g,r:['0px','0px','262px','30px','auto','auto'],f:[x4,im+g5,'0px','0px']}],style:{'${Stage}':{isStage:true,r:['null','null','149px','30px','auto','auto'],overflow:'hidden',f:[x6]}}},tt:{d:1000,a:y,data:[["eid5",lf,0,1000,"easeInOutQuart",e7,'0px','-14px']]}}};AdobeEdge.registerCompositionDefn(compId,symbols,fonts,scripts,resources,opts);})("EDGE-55334291");
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;Edge.registerEventBinding(compId,function($){
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${Pasted2}","mouseover",function(sym,e){sym.play();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){sym.stop();});
//Edge binding end
})("stage");
//Edge symbol end:'stage'
})})(AdobeEdge.$,AdobeEdge,"EDGE-55334291");