(function(compId){var _=null,y=true,n=false,x1='6.0.0',x8='35px',x16='rgba(0,0,0,0)',x22='rgb(0, 0, 0)',g='image',x42='236px',x39='Rectangle6',x23='rgba(198,152,106,1.00)',x29='32px',x18='7px',x20='2px',x='text',zx='scaleX',e45='${Rectangle2Copy2}',x37='197px',m='rect',x14='0px',e44='${Group}',x30='6px',x41='true',i='none',x43='visible',x26='1.8',x3='6.0.0.400',x36='1px',x6='group',x19='34px',x13='26px',lf='left',x34='Text2Copy2',x24='78px',x33='break-word',p='px',x38='62px',x31='Arial, Helvetica, sans-serif',x21='Rectangle2Copy3',l='normal',x40='rgba(198,152,106,0.00)',x11='auto',x15='11px',x28='198px',x2='5.0.0',x9='37',x4='rgba(255,255,255,1)',x27='Rectangle2Copy2',x12='dugme',x32='400',x25='42px',xc='rgba(0,0,0,1)',x5='Group',x10='17px',x7='110px';var g17='dugme.svg';var s35="<p style=\"margin: 0px; text-align: center;\">​<span style=\"font-family: lato, sans-serif; font-weight: 900; font-size: 15px; color: rgb(255, 255, 255);\">FIND OUT</span></p>";var im='images/',aud='media/',vid='media/',js='js/',fonts={'lato, sans-serif':'<script src=\"http://use.edgefonts.net/lato:n9,i4,n1,i7,i9,n7,i1,i3,n4,n3:all.js\"></script>'},opts={'gAudioPreloadPreference':'auto','gVideoPreloadPreference':'auto'},resources=[],scripts=[],symbols={"stage":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{id:'strela1',symbolName:'strela1',t:m,r:['-20px','7px','198','52','auto','auto'],cu:'pointer'}],style:{'${Stage}':{isStage:true,r:[undefined,undefined,'160px','70px'],overflow:'hidden',f:[x4]}}},tt:{d:0,a:y,data:[]}},"strela1":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{id:x5,t:x6,r:[x7,x8,x9,x10,x11,x11],c:[{id:x12,t:g,r:[x13,x14,x15,x10,x11,x11],f:[x16,im+g17,x14,x14]},{r:[x14,x18,x19,x20,x11,x11],id:x21,s:[0,x22,i],t:m,f:[x23]}]},{r:[x24,x25,x25,x20,x11,x11],tf:[[],[],[],[x26]],id:x27,s:[0,x22,i],t:m,f:[x23]},{r:[x14,x14,x28,x29,x11,x11],ts:[x30,x14,'','',i],n:[x31,[24,p],xc,x32,i,l,x33,l],id:x34,text:s35,align:lf,t:x},{r:[x36,x14,x37,x38,x11,x11],id:x39,s:[0,x22,i],t:m,f:[x40]}],style:{'${symbolSelector}':{isStage:x41,r:[undefined,undefined,x42,x38],overflow:x43}}},tt:{d:250,a:n,data:[["eid28",lf,0,250,"easeOutQuart",e44,'88px','110px'],["eid26",lf,0,250,"easeOutQuart",e45,'78px','68px'],["eid27",zx,0,250,"easeOutQuart",e45,'0.94','1.8']]}}};AdobeEdge.registerCompositionDefn(compId,symbols,fonts,scripts,resources,opts);})("EDGE-11918746");
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;Edge.registerEventBinding(compId,function($){
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${strela1}","mouseover",function(sym,e){sym.getSymbol("strela1").play();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${strela1}","mouseout",function(sym,e){sym.getSymbol("strela1").playReverse();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){sym.getSymbol("strela1").stop(0);});
//Edge binding end
})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'strela1'
(function(symbolName){})("strela1");
//Edge symbol end:'strela1'
})})(AdobeEdge.$,AdobeEdge,"EDGE-11918746");