
(function(compId){var _=null,y=true,n=false,x1='6.0.0',x2='5.0.0',x6='35px',x16='rgba(0,0,0,0)',x37='27px',x19='rgb(0, 0, 0)',g='image',x42='236px',x36='Rectangle6',x23='rgba(198,152,106,1.00)',x35='32px',x20='7px',x22='2px',x='text',zx='scaleX',m='rect',x13='0px',e44='${Rectangle2Copy2}',x5='110px',e43='${Group}',x24='1.8',i='none',x41='visible',x30='break-word',x3='6.0.0.400',x38='137px',x11='group',x21='34px',x12='26px',x34='198px',x32='6px',x25='78px',x31='Text2Copy2',lf='left',x39='62px',x28='Arial, Helvetica, sans-serif',x27='Rectangle2Copy2',l='normal',x40='rgba(198,152,106,0.00)',x9='auto',x14='11px',p='px',x8='17px',x4='rgba(255,255,255,1)',x7='37',x15='dugme2',x29='400',x26='42px',xc='rgba(0,0,0,1)',x18='Rectangle2Copy3',x10='Group';var g17='dugme2.svg';var s33="<p style=\"margin: 0px; text-align: center;\">​<span style=\"font-family: lato, sans-serif; font-weight: 900; font-size: 15px; color: rgb(255, 255, 255);\">FIND OUT</span></p>";var im='images/',aud='media/',vid='media/',js='js/',fonts={'lato, sans-serif':'<script src=\"http://use.edgefonts.net/lato:n9,i4,n1,i7,i9,n7,i1,i3,n4,n3:all.js\"></script>'},opts={'gAudioPreloadPreference':'auto','gVideoPreloadPreference':'auto'},resources=[],scripts=[],symbols={"stage":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{id:'strela1',symbolName:'strela1',t:m,r:['-20px','7px','198','52','auto','auto'],cu:'pointer'}],style:{'${Stage}':{isStage:true,r:['null','null','160px','70px','auto','auto'],overflow:'hidden',f:[x4]}}},tt:{d:0,a:y,data:[]}},"strela1":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x5,x6,x7,x8,x9,x9],id:x10,t:x11,c:[{r:[x12,x13,x14,x8,x9,x9],id:x15,t:g,f:[x16,im+g17,x13,x13]},{t:m,id:x18,s:[0,x19,i],r:[x13,x20,x21,x22,x9,x9],f:[x23]}]},{tf:[[],[],[],[x24]],r:[x25,x26,x26,x22,x9,x9],id:x27,s:[0,x19,i],t:m,f:[x23]},{n:[x28,[24,p],xc,x29,i,l,x30,l],t:x,align:lf,id:x31,ts:[x32,x13,'','',i],text:s33,r:[x13,x13,x34,x35,x9,x9]},{t:m,id:x36,s:[0,x19,i],r:[x37,x13,x38,x39,x9,x9],f:[x40]}],style:{'${symbolSelector}':{overflow:x41,r:[_,_,x42,x39]}}},tt:{d:250,a:n,data:[["eid28",lf,0,250,"easeOutQuart",e43,'88px','110px'],["eid26",lf,0,250,"easeOutQuart",e44,'78px','68px'],["eid27",zx,0,250,"easeOutQuart",e44,'0.94','1.8']]}}};AdobeEdge.registerCompositionDefn(compId,symbols,fonts,scripts,resources,opts);})("OJSVIJETLAMAJSKAZORO");
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;Edge.registerEventBinding(compId,function($){
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${strela1}","mouseover",function(sym,e){sym.getSymbol("strela1").play();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${strela1}","mouseout",function(sym,e){sym.getSymbol("strela1").playReverse();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){sym.getSymbol("strela1").stop(0);});
//Edge binding end
})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'strela1'
(function(symbolName){})("strela1");
//Edge symbol end:'strela1'
})})(AdobeEdge.$,AdobeEdge,"OJSVIJETLAMAJSKAZORO");